<template>
  <v-container>
    <v-row class="text-center">
      <v-col cols="12">
        <v-img
          :src="require('../assets/logo.png')"
          class="my-3"
          contain
          height="200"
        />
      </v-col>

      <v-col class="mb-4">
        <h1 class="display-2 font-weight-bold mb-3">
          SISTEMA DE CONTROL AG AVIATION SUPPLIERS
        </h1>


        <p class="subheading font-weight-regular">
          EL SISTEMA DE CONTROL AG AVIATION SUPPLIERS TIENE DERECHOS RESERVADOS 2024.          
        </p>
      </v-col>

      <v-col
        class="mb-5"
        cols="12"
        >
        <h2 class="headline font-weight-bold mb-5">
          
        </h2>      
      </v-col>
    </v-row>
  </v-container>
</template>

<script>

export default {
  name: 'HelloWorld',

  data: () => ({
    
  }),
}
</script>
